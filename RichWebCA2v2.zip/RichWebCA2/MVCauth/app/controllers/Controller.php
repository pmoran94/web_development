 <?php
	class Controller {
		private $model;
		/*
		Switch Statement declared to choose which action is been used by the user
		*/
		public function __construct($model, $action = null, $parameters) {
			$this->model = $model;
			switch ($action) {
				case "insertNewUser" :
					$this->insertNewUser ( $parameters );
					break;
				case "loginUser" :
					$this->loginUser ( $parameters );
					break;
				case "logout" :
					$this->logoutUser ();
					break;
				case "updateUser" : 
					$this->updateUser($parameters);
					break;
				case "insertNewRecord":
					$this->insertNewRecord($parameters);
					break;
				case "insertSuggestion":
					$this->insertSuggestion($parameters);
					break;
				case "apprSuggestion":
					$this->approveSuggestion($parameters);
					break;
				case "rejectSuggestion":
					$this->rejectSuggestion($parameters);
					break;
				case "updateMovie":
					$this->updateMovie($parameters);
					break;
				case "viewUsers":
					$this->getAllUsers();
					break;
				case "deleteMovie":
					$this->deleteMovie($parameters);
					break;
				case "deleteUser":
					$this->deleteUser();
					break;
				case "newAdmin":
					$this->newAdmin($parameters);
					break;
				case "search":
					$this->search($parameters);
					break;
				case "up":
					$this->voteUp();
					break;
				case "down":
					$this->voteDown();
				default :
					break;
			}
			
			//Call the prepareIntroMessage() method from model after the switch statement is cleared
			$this->model->prepareIntroMessage ();
			//Calling the updateHeader  method, which calls methods from the model to check the login status of the user, and to update that status if needed
			$this->updateHeader ();
			$this->model->getAllUsers();
			$this->model->getAllRecords();
			$this->model->getAllSuggestions();
			$this->model->userDetails();
			#$this->model->search($parameters);
		}

		function voteUp(){
			$id = $_POST['id'];
			$this->model->voteUp($id);
		}
		function voteDown(){
			$id = $_POST['id'];
			$this->model->voteDown($id);
		}
		
		function search($parameters){
			$search = $parameters['search'];
			$this->model->search($search);
		}
		
		function deleteMovie($parameters){
			$mID = $parameters ['fId'];
			$this->model->deleteMovie($mID);
		}
		
		function deleteUser(){
			$uid = $_POST['uid'];
			$this->model->deleteUser($uid);
		}
		/**
		 * Validate the input parameters, and if successful, and user does not exist,
		 * insert the new user in the database
		 *
		 * @param : $parameters
		 *        	- array containing the parameters to be validated
		 */
		 
		function insertNewUser($parameters) {
			$email = $parameters ["fEmail"];
			$username = $parameters ["fUsername"];
			$password = $parameters ["fPassword"];
			
			//All fields must be filled
			if (! empty ( $username ) && ! empty ( $password ) && ! empty ( $email )) {
				/*
				In this if statement , the controller checks various validity methods from the model. 
				This is mainly to ensure that the new  email that the new user has entered does not match an existing user and that character lenght and casings are adequate
				*/
				if ($this->model->validationFactory->isLengthStringValid ( $username, NEW_USER_FORM_MAX_USERNAME_LENGTH ) && $this->model->validationFactory->isLengthStringValid ( $password, NEW_USER_FORM_MAX_PASSWORD_LENGTH ) && $this->model->validationFactory->isEmailValid ( $email )) {
					/*
					Here , the controller is calling the authentication methods(isUserExisting()) from the authenticationFactory of the model but from here the the isUserExisting method is called from the usersDAO where it queries the database 
					to see if the username entered is existing the database.
					It is mainly checking that the new username is not already in use.
					It then passes the password value entered, to the getHashValue() method in the model's authentication factory to encrypt(sha-1) the users password to be stored in the database
					*/
					if (! $this->model->authenticationFactory->isUserExisting ( $username )) {
					// the hashed password is saved in a variable and along with the new username .....
						$hashedPassword = $this->model->authenticationFactory->getHashValue ( $password );
						//...... is inserted to the database
						// the hasRegistrationFailed methosd is assigned false so will not take affect 
						//the user is notified of the completed insertion
						if ($this->model->insertNewUser ( $username,$email, $hashedPassword )) {
							$this->model->hasRegistrationFailed = false;
							$this->model->setConfirmationMessage();
							return (true);
						}
						
						/*
						The model is holding all the error messages, therefore should any of the aspects 
						fail during user insertion the user will be notified of where and why they failed
						*/
					} else
						$this->model->setUpNewUserError ( NEW_USER_FORM_EXISTING_ERROR_STR );
				} else
					$this->model->setUpNewUserError ( NEW_USER_FORM_ERRORS_STR );
			} else
				$this->model->setUpNewUserError ( NEW_USER_FORM_ERRORS_COMPULSORY_STR );
			
			$this->model->hasRegistrationFailed = true;
			$this->model->updateLoginErrorMessage ();
			return (false);
		}
		

		function newAdmin($parameters){
			$userId = $parameters["fId"];

			$this->model->newAdmin($userId);

		}

		/**
		 * Validate the input parameters, and if successful, authenticate the user.
		 * If authentication process is ok, login the user.
		 *
		 * @param : $parameters
		 *        	- array containing the parameters to be validated. 
		 *        This is the $_REQUEST super global array.
		 */
		function loginUser($parameters) {
			$username = $parameters ["fUser"];
			$password = $parameters ["fPassword"];
			
			// both the username and password need to provided in order for user login 
			if (! (empty ( $username ) && empty ( $password ))) {
				// checks the the validaton factory to make to make sure that the user trying to log in has entered the sufficient amount of characters
				if ($this->model->validationFactory->isLengthStringValid ( $username, NEW_USER_FORM_MAX_USERNAME_LENGTH ) && $this->model->validationFactory->isLengthStringValid ( $password, NEW_USER_FORM_MAX_PASSWORD_LENGTH )) {
					//here the  controller calls the getUserPasswordDigest from the model, which calls it from the usersDAO ..which queries the database for the hash passwords which matches the entered username
					$databaseHashedPassword = $this->model->getUserPasswordDigest ( $username );
					//here the controller calls the getHashValue from the authenticationFactory  and stores the hash password value which teh user has just entered in.
					
					$userHashedPassword = $this->model->authenticationFactory->getHashValue ( $password );
					/*
					These 2 hash values  are then compared to check if correct credentials have been entered.
					Then get the userID from the model method which calls it from the usersDAO
					*/
					if ($databaseHashedPassword == $userHashedPassword) {
						$userId = $this->model->getUserId ( $username );
						$this->model->loginUser ( $userId, $username );
						$this->model->updateLoginStatus ();
						$this->model->hasAuthenticationFailed = false;
						
						return;
					}
				}
			}
			$this->model->updateLoginErrorMessage ();
			$this->model->hasAuthenticationFailed = true;
			return;
		}
		// method to call the logoutUser method from the model which calls it from the authenticationFactory
		function logoutUser() {
			$this->model->logoutUser ();
		}
		// method to check if the user is logged in and to update the login status  which calls it from the authenticationFactory
		function updateHeader() {
			if ($this->model->isUserLoggedIn ())
				$this->model->updateLoginStatus ();
		}
		
		
		function insertNewRecord($parameters) {
			$MName = $parameters ["fMovie"];
			$MCast = $parameters ["fCast"];
			$MDesc = $parameters ["fDesc"];
			$MRate = $parameters ["fRate"];
			
			//All fields must be filled
			//if (! empty ( $MName ) && ! empty ( $MDesc ) ) {
				/*
				In this if statement , the controller checks various validity methods from the model. 
				This is mainly to ensure that the new  email that the new user has entered does not match an existing user and that character lenght and casings are adequate
				*/
				//if ($this->model->validationFactory->isLengthStringValid ( $username, NEW_USER_FORM_MAX_USERNAME_LENGTH ) && $this->model->validationFactory->isLengthStringValid ( $password, NEW_USER_FORM_MAX_PASSWORD_LENGTH ) && $this->model->validationFactory->isEmailValid ( $email )) {
					/*
					Here , the controller is calling the authentication methods(isUserExisting()) from the authenticationFactory of the model but from here the the isUserExisting method is called from the usersDAO where it queries the database 
					to see if the username entered is existing the database.
					It is mainly checking that the new username is not already in use.
					It then passes the password value entered, to the getHashValue() method in the model's authentication factory to encrypt(sha-1) the users password to be stored in the database
					*/
					//if (! $this->model->authenticationFactory->isUserExisting ( $username )) {
					// the hashed password is saved in a variable and along with the new username .....
						//$hashedPassword = $this->model->authenticationFactory->getHashValue ( $password );
						//...... is inserted to the database
						// the hasRegistrationFailed methosd is assigned false so will not take affect 
						//the user is notified of the completed insertion
						if ($this->model->insertNewRecord ( $MName,$MCast, $MDesc ,$MRate )) {
							$this->model->hasRegistrationFailed = false;
							$this->model->setConfirmationMessage();
							return (true);
						}
						
						/*
						The model is holding all the error messages, therefore should any of the aspects 
						fail during user insertion the user will be notified of where and why they failed
						*/
					//} else
				//		$this->model->setUpNewUserError ( NEW_USER_FORM_EXISTING_ERROR_STR );
				//} else
				//	$this->model->setUpNewUserError ( NEW_USER_FORM_ERRORS_STR );
			//} else
				//$this->model->setUpNewUserError ( NEW_USER_FORM_ERRORS_COMPULSORY_STR );
			
			//$this->model->hasRegistrationFailed = true;
			//$this->model->updateLoginErrorMessage ();
			//return (false);
		}		

		function insertSuggestion($parameters) {
			$MName = $parameters ["fMovie"];
			$MCast = $parameters ["fCast"];
			$MDesc = $parameters ["fDesc"];
			$MRate = $parameters ["fRate"];

			$user = $_SESSION['user_id'];
			
						if ($this->model->insertSuggestion ( $user,$MName,$MCast, $MDesc ,$MRate )) {
							$this->model->hasRegistrationFailed = false;
							$this->model->setConfirmationMessage();
							return (true);
						}
						
		}

		function approveSuggestion($parameters){
			$mID = $parameters['sid'];
			$mName = $parameters['sname'];
			$mCast = $parameters['scast'];
			$mDesc = $parameters['sdesc'];
			$mRate = $parameters['srate'];

			$this->model->approveSuggestion($mID,$mName,$mCast,$mDesc,$mRate);
			
		}	

		function rejectSuggestion($parameters){
			$mID = $parameters['sid'];

			$this->model->rejectSuggestion($mID);
		}
		
		function updateUser($parameters){
			$uid = $_SESSION['user_id'];
			$username = $parameters["fUsername"];
			$password = $parameters["fPassword"];
			$email = $parameters["fEmail"];

			$newHashedPassword = $this->model->authenticationFactory->getHashValue ( $password );

			$currentUsername = $_SESSION['username']; 
			$currentPassword = $this->model->getUserPasswordDigest ( $currentUsername );
			$currentEmail = $this->model->authenticationFactory->getUserEmail($uid);

			if(!empty($username) && !empty($password) && !empty($email)){
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (!empty($username) && !empty($password) && empty($email)) {
				$email = $currentEmail;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (!empty($username) && empty($password) && !empty($email)) {
				$newHashedPassword = $currentPassword;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (empty($username) && !empty($password) && !empty($email)) {
				$username = $currentUsername;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (!empty($username) && empty($password) && empty($email)) {
				$newHashedPassword = $currentPassword;
				$email = $currentEmail;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (empty($username) && !empty($password) && empty($email)) {
				$username = $currentUsername;
				$email = $currentEmail;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else if (empty($username) && empty($password) && !empty($email)) {
				$username = $currentUsername;
				$newHashedPassword = $currentPassword;
				$this->model->updateUser($uid,$username,$newHashedPassword,$email);
			}
			else{
				;
			}
		
		}
		
		function updateMovie($parameters){
			$mID = $parameters["fId"];
			$mName = $parameters["fMname"];
			$mCast = $parameters["fMcast"];
			$mDesc = $parameters["fMdesc"];
			$mRate = $parameters["fMrate"];
			$this->model->updateMovie($mID,$mName,$mCast,$mDesc,$mRate);
		}		
	}
	?>