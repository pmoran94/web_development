<?php
require_once("dao.php");
class contentDAO extends BaseDAO{

	function messagesDAO($dbMng) {
		parent::BaseDAO($dbMng);
	}

	public function voteUp($id){

		$sqlQuery = "UPDATE records ";
		$sqlQuery .= "SET rating=rating + 1 ";
		$sqlQuery .= "WHERE id='$id' ";
		$result = $this->getDbManager()->executeQuery($sqlQuery);			

	}
	public function voteDown($id){
		$sqlQuery = "UPDATE records ";
		$sqlQuery .= "SET rating=rating - 1 ";
		$sqlQuery .= "WHERE id='$id' ";
		$result = $this->getDbManager()->executeQuery($sqlQuery);			
	}
	
	public function insertSuggestion( $user,$MName,$MCast, $MDesc ,$MRate ){

		$sqlQuery = "INSERT INTO suggestions (user_id, name , cast,  description , default_rating ) ";
		$sqlQuery .= "VALUES ( '$user','$MName', '$MCast' , '$MDesc' , '$MRate' ) ";		
		
		$result = $this->getDbManager()->executeQuery($sqlQuery);
		return $result;
	}

	public function deleteSuggestion($mID){

		$sqlQuery = "DELETE from suggestions ";
		$sqlQuery .= "WHERE id='$mID' ";

		$result = $this->getDbManager()->executeQuery($sqlQuery);
	
	}

	public function approveSuggestion($mID,$mName,$mCast,$mDesc,$mRate){
		$sqlQuery = "INSERT into records (name ,cast, description , rating ) ";
		$sqlQuery .="VALUES ('$mName','$mCast','$mDesc','$mRate') ";

		$result = $this->getDbManager()->executeQuery($sqlQuery);
		return $result;
	}

	public function getAllRecords(){
	
		$sqlQuery = "SELECT * ";
		$sqlQuery .= "FROM records ";
		
		$result = $this->getDbManager()->executeSelectQuery($sqlQuery);
		
		return $result; 
	}
	public function getAllSuggestions(){
	
		$sqlQuery = "SELECT * ";
		$sqlQuery .= "FROM suggestions ";
		
		$result = $this->getDbManager()->executeSelectQuery($sqlQuery);
		
		return $result; 
	}
	public function deleteMovie($mID){
		$sqlQuery = "DELETE FROM records ";
		$sqlQuery .= "WHERE id = '$mID' ";		
		//Calls the method from the DAOFactory and passes in the query to be  execute, and the result is stored
		$result = $this->getDbManager()->executeQuery($sqlQuery);
	
	}
	
	public function searchResults($parameters){
		$sqlQuery = "SELECT * ";
		$sqlQuery .= "FROM records ";
		$sqlQuery .= " WHERE id ";
		$sqlQuery .= "like '%$parameters%' OR name like '%$parameters%' OR description like '%$parameters%' OR rating like '%$parameters%'  ";
		
		$result = $this->getDbManager()->executeSelectQuery($sqlQuery);
		return $result;
	}
	
	public function updateMovie($mID,$mName,$mCast,$mDesc,$mRate){
		
		$sqlQuery = "UPDATE records ";
		$sqlQuery .= "SET name='$mName' , cast='$mCast',  description='$mDesc' , rating='$mRate' ";
		$sqlQuery .= "WHERE id='$mID' ";
		$result = $this->getDbManager()->executeQuery($sqlQuery);		
	}
	
	public function insertNewRecord($MName,$MCast,$MDesc,$MRate){
	
		$sqlQuery = "INSERT INTO records (name ,cast, description , rating ) ";
		$sqlQuery .= "VALUES ( '$MName' ,'$MCast', '$MDesc' , '$MRate' ) ";		
		
		$result = $this->getDbManager()->executeQuery($sqlQuery);
		return $result;
	}	

}
?>