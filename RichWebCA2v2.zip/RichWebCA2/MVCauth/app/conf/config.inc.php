<?php
/*
Assigning some fixed values which will be used throughout the whole application
*/
/* database constants */
define("DB_HOST", "localhost" ); 		
define("DB_USER", "root" ); 			
define("DB_PASS", "root" ); 		
define("DB_PORT", 3306);				
define("DB_NAME", "wdd" ); 		

/* application constants */
define("APP_NAME", "Movie Ratings" ); 		

/* new user form constants */
define("NEW_USER_FORM_ERRORS_STR", "Errors exist in the form");
define("NEW_USER_FORM_ERRORS_COMPULSORY_STR", "All the fields are compulsory");
define("NEW_USER_FORM_EXISTING_ERROR_STR", "Another user already exists in the system with the same username");
define("NEW_USER_FORM_MAX_USERNAME_LENGTH", 30);	
define("NEW_USER_FORM_MAX_PASSWORD_LENGTH", 20); 
define("NEW_USER_FORM_REGISTRATION_CONFIRMATION_STR", "You have registered successfully, Please Log In");
define("NEW_USER_FORM_SYSTEM_ERROR_STR", "Something went wrong during registration");
define("NON_LOGGED_IN_USER_STR","Records may not be altered with by User's Who are not logged in!");
define("NON_LOGGED_IN_USER_STR_USERS","You must be logged in to update your account!");
define("DELETE_CURRENT_USER_SUCCESS","You have successfully been removed from our records.");


/* login user form constants */
define("LOGIN_USER_FORM_MAX_USERNAME_LENGTH", 30);	
define("LOGIN_USER_FORM_MAX_PASSWORD_LENGTH", 20); 	
define("LOGIN_USER_FORM_WELCOME_STR", "Welcome");
define("LOGIN_USER_FORM_AUTHENTICATION_ERROR", "Incorrect Details");
define("LOGIN_USER_FORM_LOGOUT_STR", "Logout");

/* misc */
define("INDEX_INTRO_MESSAGE_STR", " " . APP_NAME. "");
define("LOGGED_IN_USER_MENU", "<ul><li>option 1</li><li>option 2 </li></li>");
define("USER_NOT_LOGGED_IN","Records may not be altered with by User's who are not logged in.");
?>