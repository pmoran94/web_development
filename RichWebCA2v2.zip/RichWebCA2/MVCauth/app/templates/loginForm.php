<h2 class="algerian" style="color:#fbb83a">Login</h2>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='loginUser' /> 
			<label for="fUser"></label> <input type="text"
				id="fUser" name="fUser" placeholder="Username"
				maxlength="50"  style="height:40px;width:100%" required />
			
			<label for="fPassword"></label> <input type="password"
				id="fPassword" name="fPassword" placeholder="password"
				maxlength="25" style="height:40px;width:100%" required />
		
	
		
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-warning" style="color:grey">Login</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>
