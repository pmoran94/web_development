<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='search' />
		<p>
			<label for="search"></label> <input type="text"
				id="search" name="search" placeholder="Search Movie, Game, Series"
				maxlength="25" required style="width:100%;height:100px" />
		</p>
		
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-warning" style="color:grey">Search</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>