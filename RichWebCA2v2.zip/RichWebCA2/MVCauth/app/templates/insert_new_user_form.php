<h3 class="algerian" style="color:#fbb83a">Welcome! It's Free!</h3>
<h4 style="color:red">Please Fill in all fields.</h4>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='insertNewUser' />

		<table class="table">
		<tr>
			<td><label for="fUsername">Username   </label><br>
			<input type="text"
				id="fUsername" name="fUsername" placeholder="Username"
				maxlength="25" style="height:40px;width:100%" required /></td>
		</tr>
		<tr>
			<td><label for="fPassword">Password </label><br>
			<input type="password"
				id="fPassword" name="fPassword" placeholder="Password"
				maxlength="25" style="height:40px;width:100%" required /></td>
		</tr>
		<tr>
			<td><label for="fEmail">Email</label><br>
			<input type="email"
				id="fEmail" name="fEmail" placeholder="E-mail"
				maxlength="50" style="height:40px;width:100%" required /></td>
		</tr>
		</table>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-warning" style="color:grey">Sign up</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>