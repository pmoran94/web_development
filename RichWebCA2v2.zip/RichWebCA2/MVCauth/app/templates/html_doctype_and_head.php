<html lang="it">
<head>
<meta charset="utf-8">
<title><?php echo $appName ; ?></title>
<meta name="description" content="<?php echo $appName; ?>">
<meta name="author" content="luca">

<link href="css/bootstrap.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,500' rel='stylesheet'>
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<style type="text/css">
body {
	padding-top: 30px;
}
error  {
    color:red;
    font-family:courier;
    font-size:160%;
	padding-right:20px;
	padding-top:20px;
}


</style>
</head>