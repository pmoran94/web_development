
<div class="col-lg-4">
</div>
<div class="col-lg-4">
	<?php 
	if(isset($_POST['search'])){
		include_once "searchresults.php";

	}
	else{
		echo $middleBox ;
	}?>				

</div>
<div class="col-lg-4">
</div>