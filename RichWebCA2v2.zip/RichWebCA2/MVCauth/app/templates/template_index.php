<!DOCTYPE html>
<?php include_once 'html_doctype_and_head.php'; ?>
<body>

<?php ?>

	<div class="container-fluid">
		<div class="row-fluid" style="margin-top: 40px">
		
			<div class="col-lg-2">
			</div>

			<div class="col-lg-8" style="background-color:lavender; background:rgba(255,255,255,0.3);">
				<!-- Start navbar div-->
				<div class="navbar navbar-inverse" style="margin-top:10px">
					<!-- Start  of container div-->
					<div class="container-fluid">
						<!-- navbar header-->
						<div class="navbar-header">
							
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navBar1">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div> <!-- End of Navbar Header-->
							
						<!-- Start of navbar-collapse div-->
						<div class="collapse navbar-collapse" id="navBar1">
							<!-- Start of navbar unordered list-->

							<ul class="nav nav-tabs center">	
								<li><a href="?button=viewRecs">View all Movies</a></li>				
								<!-- Start of list item (dropdown)-->
								<li>
									<a href="?button=imdbsearch">IMdB</a>
								</li><!-- End of list item (dropdown)-->
								<li>
									<a href="?button=suggestMovie">Suggest New Movie</a>
								</li>
								<li>
									<a href="?button=startChat">Chat</a>
								</li>
							</ul><!-- End of navbar unorderer list-->	
						</div><!-- End of navbar-collapse div-->
					</div><!-- End of container div-->
				</div><!-- End of navbar div-->
					<?php 		
						
						if($_GET['button'] == 'viewRecs'){
							include_once "view_records.php";
						}
						else if($_GET['button'] =='userDetails'){
							include_once "userDetails.php";
						}
						else if($_GET['button'] == 'change'){
							include_once "updateUser.php";
						}
						else if(isset($_POST['search'])){
							include_once "searchresults.php";
						}
						else if(isset($_GET['button'])){
							echo $middleBox;
						}
						else{
							include_once "view_records.php";
						}?>
			</div><!-- End of Container fluid top-->
			
			<div class="col-lg-2">
			</div>
			
			<!--
			//<div class="col-lg-6">
				<?php 
				//if(isset($_POST['search'])){
				//	include_once "searchresults.php";
				//}
			//	else{
			//		echo $middleBox ;
			//	}?>
			//</div>-->
		</div>

		</div>


		<!-- Start navbar div-->
		<div class="navbar navbar-fixed-top navbar-inverse">
			<!-- Start  of container div-->
			<div class="container-fluid">
				<!-- navbar header-->
				<div class="navbar-header">
					
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navBar1">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div> <!-- End of Navbar Header-->
					
				<!-- Start of navbar-collapse div-->
				<div class="collapse navbar-collapse" id="navBar1">
				<div class="navbar-header">
      				<a class="navbar-brand" href="#">Movie Rater</a> 
    			</div>
					<!-- Start of navbar unordered list-->

					<ul class="nav nav-tabs center">	
						<li><a href="#" class="redundant"></a></li>	
						<li><a href="#" class="dead">View movies from :</a></li>				
						<!-- Start of List item-->
						<li><a href="#" class="viewRecs" >Movie Ratings</a></li><!-- End of list item-->
						<!-- Start of List item-->
						<li>
							<a href="?button=searchform">Search</a>
						</li>
						<li>
							<a href="?button=userDetails">User Details</a>
						</li>
					</ul><!-- End of navbar unorderer list-->
					<ul class="nav nav-tabs navbar-right">
						<li><?php echo $loginBox; ?></li>
					</ul>	
				</div><!-- End of navbar-collapse div-->
			</div><!-- End of container div-->
		</div><!-- End of navbar div-->
	</div><!-- End of Container fluid top-->

</body>
</html>
