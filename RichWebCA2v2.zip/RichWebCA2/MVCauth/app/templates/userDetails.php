<?php

include_once './db/simple_db_manager.php';



echo "<div class='col-lg-3'>";
echo "</div>";
echo "<div style='overflow:auto;' class='col-lg-6'>";
echo "<div ><h3>User Details </h3></div>";
echo "<table class= 'table table-hover ' border='0' style='width:100%; color:black; margin:0px'>";
echo "<thead>";
echo "<tr>
<th>Field   </th>
<th>Details   </th>    
</tr>";

echo "</thead>";
foreach ($this->model->userDetails as $row){
	echo "<tr><td>ID :</td><td>" . $row ['id'] . "</td></tr>";
	echo "<tr><td>Username :</td><td>". $row ['username'] ."</td></tr>";
	echo "<tr><td>E-mail :</td><td>" . $row ['email'] . "</td></tr>";
	echo "<tr><td>Password :</td><td>" . '******' . "</td></tr>";
	echo "<tr><td>Is an Admin :</td><td>" . $row['is_admin'] . "</td></tr>";
}
echo "</table>";
echo "</div>";

echo "<div class='col-lg-3'>";
echo "<div>";
echo "<h4><a href='?button=change'>Change Info</a></h4>";
echo "</div>";
echo "</div>";
?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>