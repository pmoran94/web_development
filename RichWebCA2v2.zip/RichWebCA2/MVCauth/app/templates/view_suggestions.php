<?php

include_once './db/simple_db_manager.php';

echo "<div ><h3>Movie Suggestions </h3></div>";
echo "<div style='overflow:auto;'>";
echo "<table class='table table-hover border='0' style='width:100%;  color:black; margin:0px'>";
echo "<thead style='background-color'>";
echo "<tr>
<th>ID  </th>
<th>User Id   </th>
<th>Movie Name:   </th>
<th>Movie Cast:   </th>
<th>Description:   </th>
<th>Default Rating:   </th>
<th>Option</th>
</tr>";
echo "</thead>";

foreach ($this->model->allSuggestions as $row){
	echo "<tr><td>" . $row ['id'] . "</td>";
	echo "<td>" . $row ['user_id'] . "</td>";
	echo "<td>" . $row ['name'] . "</td>";
	echo "<td>" . $row ['cast'] . "</td>";
	echo "<td>" . $row ['description'] . "</td>";
	echo "<td>" . $row ['default_rating'] . "</td>";

	echo "<form method='post' action='' >";
	
	echo "<input type='hidden' name='sid' value='" . $row['id'] ."'>"; 
	echo "<input type='hidden' name='sname' value='" . $row['name'] ."'>"; 
	echo "<input type='hidden' name='scast' value='" . $row['cast'] ."'>"; 
	echo "<input type='hidden' name='sdesc' value='" . $row['description'] ."'>"; 
	echo "<input type='hidden' name='srate' value='" . $row['default_rating'] ."'>"; 

	echo "<td><button type='submit' name='action' value='apprSuggestion' class='btn-success'>Approve</button>";
	echo "<button type='submit' name='action' class='btn btn-danger' value='rejectSuggestion'>Reject</button> </td>";
	echo "</tr>";
}
echo "</table>";
echo "</div>";

?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>