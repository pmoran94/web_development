<div class="col-lg-2">
</div>

<div class="col-lg-8">
	<?php
		include_once "view_records_not_logged_in.php";
	?>
</div>

<div class="col-lg-2">
</div>