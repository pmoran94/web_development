<div class="col-lg-2">
</div>

<div class="col-lg-8">
	<?php
		include_once "view_records.php";
	?>
</div>

<div class="col-lg-2">
</div>