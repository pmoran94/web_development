<?php

include_once './db/simple_db_manager.php';

echo "<div ><h3>Movies </h3></div>";
echo "<div style='overflow:auto;'>";
echo "<table class='table table-hover border='0' style='width:100%; color:black; margin:0px'>";
echo "<thead style='background-color'>";
echo "<tr>
<th>ID  </th>
<th>Name:   </th>
<th>Cast:   </th>
<th>Description:   </th>
<th>Rating:   </th>
<th>You Rate:   </th>
</tr>";
echo "</thead>";

foreach ($this->model->allRecords as $row){
	echo "<tr><td>" . $row ['id'] . "</td>";
	echo "<td>" . $row ['name'] . "</td>";
	echo "<td>" . $row ['cast'] . "</td>";
	echo "<td>" . $row ['description'] . "</td>";
	echo "<td>" . $row ['rating'] . "</td>";

	echo "<td style='width:20%'><form method='post' action=''>";
	echo "<input type='hidden' name='id' value='" . $row['id'] . "'/>";
	echo "<input type='hidden' name='mname' value='". $row['name']. "'>";

	echo "<button type='submit' class='btn btn-success' name='action' value='up'><span class='glyphicon glyphicon-thumbs-up'></span></button>";
	echo "<button type='submit' class='btn btn-danger' name='action' value='down'><span class='glyphicon glyphicon-thumbs-down'></span></button>";
	echo "<button type='submit' class='btn btn-warning' name='action' ><span class='glyphicon glyphicon-menu-down'></span></button>";
	echo "</form></td>";
	echo "</tr>";
}
echo "</table>";
echo "</div>";
?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>