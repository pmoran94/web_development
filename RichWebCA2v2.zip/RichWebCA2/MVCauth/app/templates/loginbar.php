<form class="navbar-form navbar-right" role="form" method="post"
	action="index.php" autocomplete="off">
	<div class="form-group">
		<input id='action' type='hidden' name='action' value='loginBar' /> 
		<a href='?button=login' id="loginForm" name="loginForm">Login</a>
		/
		<a href='?button=registerbutton' id="registerForm" name="registerForm">Register</a>
	</div>
</form>
