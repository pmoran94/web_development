<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
</script>

<h2 class="algerian" style="color:#fbb83a">Update/Delete Movie(By ID)</h2>
<h4 style="color:red">Enter ID of Movie.</h4>
<form action="" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='id' /> 
			<label for="fId"></label> <input type="number"
				id="fId" name="fId" placeholder="Movie Id"
				style="height:40px;width:100%" required />
		
		<p>
		<div class="form-group">
			<div class="controls">
				<a  href="javascript:toggle();" name="displayText"><button type="button" class="btn btn-warning" id="proceedToUpdate" name="proceedToUpdate" style="color:grey">Proceed to Update</button></a>
				<button type="submit" class="btn btn-danger" name="action" value="deleteMovie" style="color:grey">Delete</button>
			</div>
		</div>
		<div id="toggleText" style="display: none">
			<table class= 'table table-responsive ' border='5' style='width:50%; color:black; margin:0px'>
			<thead>
			<tr>
			<th>New Movie Info.   </th>  
			</tr>

			</thead>
			<tr><td><input type='text' id='fMname' name='fMname' placeholder='Movie Name'
							maxlength='25' style='height:100%;width:100%' /></td></tr>
			<tr><td><input type='text' id='fMcast' name='fMcast' placeholder='New Cast'
							maxlength='100' style='height:100%;width:100%' /></td></tr>
			<tr><td><input type='text' id='fMdesc' name='fMdesc' placeholder='New Description'
							maxlength='50' style='height:100%;width:100%' /></td></tr>
			<tr><td><input type="number" id="fMrate" name="fMrate" placeholder="New Rating"
							max="10" min="0" style="height:100%;width:100%" /></td></tr>
			</table>
			<button type='submit' class="btn btn-warning" name="action" value="updateMovie" style="color:grey">Update Movie</button>
		</div>
		</p>
	</fieldset>
</form>