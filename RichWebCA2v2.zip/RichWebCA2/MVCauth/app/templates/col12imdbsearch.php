<div class="col-lg-12">
	<?php
		include_once "/Lab7/index.html";
	?>
</div>