<h2>Delete Current User</h2>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='deleteUser' />
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-success">Delete Me</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>