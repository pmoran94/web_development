<h2 class="algerian" style="color:#fbb83a">New Admin</h2>
<h4 style="color:red">Enter User ID of User to Upgrade to Admin.</h4>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='newAdmin' /> 
			<label for="fId"></label> <input type="number"
				id="fId" name="fId" placeholder="User Id"
				style="height:40px;width:50%" required />
		
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-warning" style="color:grey">Add Admin</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>
