<?php

include_once './db/simple_db_manager.php';

echo "<div ><h3>Users </h3></div>";
echo "<div style='overflow:auto;'>";
echo "<table class= 'table table-hover ' border='0' style='width:100%; color:black; margin:0px'>";
echo "<thead>";
echo "<tr>
<th>ID  </th>
<th>Username:   </th>
<th>Email:   </th>
<th>Password:   </th>
<th>Option:   </th>     
</tr>";

echo "</thead>";
foreach ($this->model->allUsers as $row){
	echo "<td>" . $row ['id'] . "</td>";
	echo "<td>" . $row ['username'] . "</td>";
	echo "<td>" . $row ['email'] . "</td>";
	echo "<td>" . '******' . "</td>";
	echo "<form action='' method='post'>";
	echo "<input type='hidden' name='uid' value='" . $row['id'] . "'/>";
	echo "<td><button type='submit' class='btn-danger' name='action' value='deleteUser'>Del</button></td>";
	echo "</form></tr>";
}
echo "</table>";
echo "</div>";
?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>