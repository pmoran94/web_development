<?php

include_once './db/simple_db_manager.php';

echo "<div ><h3>Movies </h3></div>";
echo "<div style='overflow:auto;'>";
echo "<table class= 'table table-hover ' border='0' style='width:100%; color:black; margin:0px'>";
echo "<thead style='background-color'>";
echo "<tr>
<th>ID  </th>
<th>Name:   </th>
<th>Cast:   </th>
<th>Description:   </th>
<th>Rating:   </th>
</tr>";
echo "</thead>";

foreach ($this->model->allRecords as $row){
	echo "<tr><td>" . $row ['id'] . "</td>";
	echo "<td>" . $row ['name'] . "</td>";
	echo "<td>" . $row ['cast'] . "</td>";
	echo "<td>" . $row ['description'] . "</td>";
	echo "<td>" . $row ['rating'] . "</td>";
	echo "</tr>";
}
echo "</table>";
echo "</div>";
?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>