<h3 class="algerian" style="color:#fbb83a">Add a New Movie</h3>
<h4 style="color:red">Please Fill in all fields.</h4>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='insertNewRecord' />

		<table class="table">
			<tr>	
				<label for="fMovie">Movie Name:</label><br> 
				<input type="text"
					id="fMovie" name="fMovie" placeholder="Movie Name"
					maxlength="25" style="height:40px;width:100%" required /></tr>
			<tr>
				<label for="fCast">Cast:</label><br>
				<input type="textbox"
					id="fCast" name="fCast" placeholder="Cast"
					maxlenght="100" style="width:100%;height:100px" required /></tr>

			<tr>
				<label for="fDesc">Description:</label><br> 
				<input type="text"
					id="fDesc" name="fDesc" placeholder="description"
					maxlength="50" style="height:40px;width:100%" required /></tr>

			<tr>
			<label for="fRate">Rating:(Out of 10)</label> <input type="number"
				id="fRate" name="fRate" placeholder="rating" style="height:40px;width:100%" min="0" max="10" required /></tr>

		
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-warning">Suggest Movie</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>