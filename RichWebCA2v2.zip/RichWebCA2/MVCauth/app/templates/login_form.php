<h3>Welcome! It's Free!</h3>
<h4 style="color:red">Please Fill in all fields.</h4>
<form action="index.php" method="post">
	<fieldset>
		<input id='action' type='hidden' name='action' value='loginUser' /> 
		<p>
			<label for="fUser"></label> <input type="text"
				id="fUser" name="fUser" placeholder="Username"
				maxlength="50" required />
			
		</p>

		<p>
			<label for="fPassword"></label> <input type="password"
				id="fPassword" name="fPassword" placeholder="password"
				maxlength="25" required />
		
		</p>
		
		<p>
		<div class="form-group">
			<div class="controls">
				<button type="submit" class="btn btn-primary">Login</button>
			</div>
		</div>
		</p>
	</fieldset>
</form>
