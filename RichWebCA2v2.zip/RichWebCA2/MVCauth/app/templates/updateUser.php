<?php

include_once './db/simple_db_manager.php';
echo "<div style='overflow:auto;' class='col-lg-6'>";
echo "<div ><h3>User Details </h3></div>";
echo "<table class= 'table table-hover ' border='0' style='width:100%; color:black; margin:0px'>";
echo "<thead>";
echo "<tr>
<th>Field   </th>
<th>Details   </th>  
</tr>";

echo "</thead>";
foreach ($this->model->userDetails as $row){
	echo "<tr><td>ID :</td><td>" . $row ['id'] . "</td></tr>";
	echo "<tr><td>Username :</td><td>". $row ['username'] ."</td></tr>";
	echo "<tr><td>E-mail :</td><td>" . $row ['email'] . "</td></tr>";
	echo "<tr><td>Password :</td><td>" . '******' . "</td></tr>";
	echo "<tr><td>Is an Admin :</td><td>" . $row['is_admin'] . "</td></tr>";
}
echo "</table>";
echo "</div>";


echo "<div class='col-lg-6'>";
echo "<div><h3>&nbsp;</h3></div>";
echo "<form action='index.php' method='post' >";

echo "<table class= 'table table-responsive ' border='5' style='width:100%; color:black; margin:0px'>";
echo "<thead>";
echo "<tr>
<th>New Info.   </th>  
</tr>";

echo "</thead>";

echo "<input id='action' type='hidden' name='action' value='updateUser' />";

echo "<tr><td><input type='text' id='fUsername' name='fUsername' placeholder='Username'
				maxlength='25' style='height:100%;width:100%' /></td></tr>";
echo "<tr><td><input type='password' id='fPassword' name='fPassword' placeholder='Password'
				maxlength='25' style='height:100%;width:100%' /></td></tr>";
echo "<tr><td><input type='email' id='fEmail' name='fEmail' placeholder='E-mail'
				maxlength='50' style='height:100%;width:100%' /></td></tr>";
echo "<tr><td><button type='submit' class='btn-success'>Update</button></td></tr>";
echo "</table>";
echo "</form>";
echo "</div>";

?>

<html>
<head>
<link href ="css/misc.css" rel="stylesheet" type="text/css">
</head>
</html>