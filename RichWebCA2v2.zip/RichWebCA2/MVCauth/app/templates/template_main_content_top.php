<!DOCTYPE html>
<body>
		<div class="row-fluid" style="margin-top: 20px">
			<div class="span3" style="background:skyblue">
			</div>
			<div class="span3" style="background:skyblue">
			</div>
			<div class="span3" style="background:skyblue">
			</div>
		</div>
<body>