<?php
class View {
	private $model;
	private $controller;
	
	public function __construct($controller, $model) {
		/*
			Here both the controller and model are assigned to usable variables within the view.
		*/
		$this->controller = $controller;
		$this->model = $model;
	}
	public function output() {
		// set variables up from the model (for the template)
		$appName = $this->model->appName;
		$introMessage = $this->model->introMessage;
		$newUserErrorMessage = $this->model->newUserErrorMessage;
		
		$username = "";
		$loginBox = "";
		$authenticationErrorMessage = "";
		$rightBox = "";
		$middleBox = "";
		$confirmationMessage = "";
		$displayTables = "";
		$tableChoice = null;
		
		if ($this->model->loginStatusString != null) {
			$loginBox = "<a href='index.php?action=logout'>" . $this->model->loginStatusString . "</a>";
			// list of options available to logged in user
			$updateUserForm = file_get_contents('./templates/update_user_form.php');
			$updateRecordForm = file_get_contents('./templates/update_record_form.php');
			$registrationForm = file_get_contents('./templates/insert_new_user_form.php');
			$newRecordForm = file_get_contents('./templates/insert_new_record.php');
			$userTable = file_get_contents('./templates/view_records.php');
			$recordsTable = file_get_contents('./templates/view_records.php');
			$username = $this->model->authenticationFactory->getUsernameLoggedIn();
			$searchForm = file_get_contents('./templates/search_form.php');
			$chat = file_get_contents('./Chat/index.php');

			$option = $_GET['button'];

			if ( $this->model->authenticationFactory->isAdmin()){

				if ($option == "addMovie"){
					$middleBox = $newRecordForm;
				}
				else if($option == "addAdmin"){

					$middleBox = file_get_contents("templates/add_admin.php");
				}
				else if($option == 'updateMovie'){
					$middleBox = file_get_contents("templates/updateMovieByID.php");
				}
				else
					$middleBox = $searchForm;


				include_once ("templates/template_index_admin.php");

			}
			else
			{				
				
				
				if ($option == $updateUser){
					$middleBox = $updateUserForm;
				}
				else if($option == 'suggestMovie'){
					$middleBox = file_get_contents("templates/insert_suggestion.php");
				}
				else if($option == 'searchform'){
					$middleBox = $searchForm;
				}
				else{
					$middleBox = $searchForm;
				}
				
				include_once ("templates/template_index.php");
			}	
			
		} else {
			
			$authenticationErrorMessage = "";
			$registrationForm = file_get_contents("templates/insert_new_user_form.php");

			if ($this->model->hasAuthenticationFailed)
				$authenticationErrorMessage = $this->model->authenticationErrorMessage;
			
			$middleBox = file_get_contents ( "templates/search_form.php", FILE_USE_INCLUDE_PATH );
			
			$link = $_GET['buttonLogin'];

			if($link == 'searchButton'){
			
				$middleBox = file_get_contents("templates/search_form.php");
			}
			else if($link == 'login'){
				$middleBox = file_get_contents("templates/loginForm.php");
			}
			else if ($link == 'registerbutton'){
				$middleBox = $registrationForm;
			}
			else
				$middleBox = file_get_contents("templates/search_form.php");
			

			if (isset($_POST['insertNewUser'])){
				$confirmationMessage = "<div class='alert alert-success'>" . $this->model->signUpConfirmation . "</div>";
				$middleBox = $confirmationMessage . file_get_contents("templates/search_form.php");
			}

			
			/*if (! isset ( $this->model->hasRegistrationFailed )) {
				$middleBox = $registrationForm;
			} else if ($this->model->hasRegistrationFailed) {
				$middleBox = $newUserErrorMessage . $registrationForm;
			} else if ($this->model->hasRegistrationFailed == false) {
				$confirmationMessage = "<div class='alert alert-success'>" . $this->model->signUpConfirmation . "</div>";
				$middleBox = $confirmationMessage;
			}*/
			
		include_once ("templates/template_login.php");

		}
		
		
	}
}
?>