<?php

/*
The model the main point of interaction between all the components
*/
/*
----Include various scripts (factories , DAOS, and configuration file)
*/
include_once './conf/config.inc.php';
include_once './db/DAO_factory.php';
include_once 'validation_factory.php';
include_once 'authentication_factory.php';

class Model {
	public $DAO_Factory, $validationFactory, $authenticationFactory; // factories
	private $usersDAO, $contentDAO; // DAOs
	public $appName = "", $introMessage = "", $loginStatusString = "", $rightBox = "",$displayTables = "", $signUpConfirmation="",$middleBox = "", $allUsers="", $allRecords="",$searchResults=""; // strings
	public $newUserErrorMessage = "", $authenticationErrorMessage = "";	//error messages
	public $hasAuthenticationFailed = false, $hasRegistrationFailed=null;	//control variables
	
	
	public function __construct() {
		/*
		 Assigning various factories , DAOS, strings, error messages, and control variables
		*/
		
		$this->DAO_Factory = new DAO_Factory ();
		$this->DAO_Factory->initDBResources ();
		$this->usersDAO = $this->DAO_Factory->getUsersDAO ();
		$this->authenticationFactory = new authentication_factory ( $this->usersDAO );
		$this->validationFactory = new validation_factory ();
		$this->appName = APP_NAME;
		$this->contentDAO = $this->DAO_Factory->getContentDAO();
	}
	
	public function loginUser($userID, $username) {
		/*
		 -- Method to create a current session using the username and  id of the user who has signed in
		*/
		$this->authenticationFactory->loginUser ( $userID, $username );
	}
	public function getUserPasswordDigest($username) {
		/*
		-- Method to attain the password of the username which has been entered to the log in  , the returned value will then be compared with the password hash value 
		that the user has entered in.
		*/
		return ($this->usersDAO->getUserPasswordDigest ( $username ));
	}
	public function getUserID($username) {
		/*
			-- method to get the user id using the username which has been entered in from the login form.
			This id is gotten  from the query executed through the usersDAO -> dbManager
		*/
		return ($this->usersDAO->getUserId ( $username ));
	}
	
	
	public function getAllUsers(){
	
		$this->allUsers =  $this->usersDAO->getAllUsers();
	}
	
	public function getAllRecords(){
		$this->allRecords = $this->contentDAO->getAllRecords();
	}
	
	public function search($parameters){
		$this->searchResults = $this->contentDAO->searchResults($parameters);
	}
	
	
	
	public function prepareIntroMessage() {
		/*
		-- Method to get the intro message gotten from the config.inc.php script
		*/
		$this->introMessage = INDEX_INTRO_MESSAGE_STR;
	}

	public function setUpNewUserError($errorString) {
	// method to notify user of a an error occuring during insert new user form.
		$this->newUserErrorMessage = "<div class='alert alert-error'>" . $errorString . "</div>";
	}
	public function updateLoginStatus() {
	
		/*
		--method to update the login status of a user.
		This mainly just overwrites the login screen string
		Here Authentication error message is set to null.
		-to prevent both from appearing on screen
		*/
		$this->loginStatusString = LOGIN_USER_FORM_WELCOME_STR . " " . $this->authenticationFactory->getUsernameLoggedIn () . " | " . LOGIN_USER_FORM_LOGOUT_STR;
		$this->authenticationErrorMessage = "";
	}
	public function updateLoginErrorMessage() {
		/*
		--Method to update the login error message.
		Here the loginStatusString is set to null instead.
		-to prevent both from appearing on screen
		*/
		$this->authenticationErrorMessage = LOGIN_USER_FORM_AUTHENTICATION_ERROR;
		$this->loginStatusString = "";
	}
	public function setConfirmationMessage(){
		/*
		--The model uses this method to assign the confirmation message that the new user is now successfully set up.
		*/
		$this->signUpConfirmation = NEW_USER_FORM_REGISTRATION_CONFIRMATION_STR;
	}
	public function insertNewUser($username,$email, $hashedPassword) {
		/*
			This is the center point in which a new user is inserted to the database.
			The model is receives the username and hashedPassword and from
			here they are passed onto the "insertnewuser" method in the usersDAO
			where the sql query will be activiated using the given parameters.
		*/
		return ($this->usersDAO->insertNewUser ( $username,$email, $hashedPassword ));
	}
	
	public function updateUser($username,$password,$email){
		$hashedPassword = hash ( "sha1", $password );
		$this->usersDAO->updateUser($username,$hashedPassword,$email);
	
	}
	public function updateRecord($mID,$mName,$mDesc,$mRate){
		$this->contentDAO->updateRecord($mID,$mName,$mDesc,$mRate);
	}
	public function logoutUser() {
		/*
			This is the method to control user log out.
			It sets the login status to null and the empties the authentication error message.
			But also from here the logoutUser is method is called from the authenticationFactory -
			from here the session variables will be unset and the current session will be destroyed.
		*/
		$this->authenticationFactory->logoutUser ();
		$this->loginStatusString = null;
		$this->authenticationErrorMessage = "";
	}
	
	public function isUserLoggedIn() {
		/*
			The method is to check if there is a user logged in.
			It will receive a boolean value to know if there is a user logged in or not
		*/
		return ($this->authenticationFactory->isUserLoggedIn ());
	}
	public function __destruct() {
		/*
			This is models method to close the database connection through the DAOFactory, which calls the closeConnection method
			from the dbmanager..
		*/
		$this->DAO_Factory->clearDBResources ();
	}
	
	public function insertNewRecord($MName, $MDesc,$MRate) {
		return ($this->contentDAO->insertNewRecord ( $MName, $MDesc,$MRate ));
	}
	
	public function deleteRecord($mID){
		$this->contentDAO->deleteRecord($mID);
	}
	
	public function deleteUser($username){
		$this->usersDAO->deleteUser($username);
	}
}
?>