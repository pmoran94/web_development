# Realtime Blog Comment System

You can find the full tutorial for this example on Smashing Magazine:
http://www.smashingmagazine.com/2012/05/09/building-real-time-commenting-system/
